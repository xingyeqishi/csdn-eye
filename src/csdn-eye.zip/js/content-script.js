document.addEventListener('DOMContentLoaded', function()
{
    var nd = document.getElementById('article_content');
    nd.style.height = 'unset';
    nd.style.overflow = 'unset';
    document.querySelector('.hide-article-box').style.opacity = 0;
});

